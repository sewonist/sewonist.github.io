package rsatest;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.Cipher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HexTestServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public static final int KEY_SIZE = 2048;
	
	public static final String ALGORITHM_RSA = "RSA";
	
	public static PrivateKey recentPrivateKey;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		execute(request, response);
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		execute(request, response);
	}
	
	protected void execute(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			
			String hexString = request.getParameter("EncrytData");
			
			if(hexString != null && hexString != "") {
				byte[] hexBytes = hexToByteArray(hexString);
				
				Cipher cipher = Cipher.getInstance("RSA");
				cipher.init(Cipher.DECRYPT_MODE, recentPrivateKey);
				
				byte[] decryptedBytes = cipher.doFinal(hexBytes);
				
				String decryptedString = new String(decryptedBytes, "utf-8");
				
				request.setAttribute("DecryptedString", decryptedString);
			}
			
		
			KeyPairGenerator generator = KeyPairGenerator.getInstance(ALGORITHM_RSA);
			generator.initialize(KEY_SIZE);
			
			KeyPair keyPair = generator.genKeyPair();
			KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM_RSA);
			
			PublicKey publicKey = keyPair.getPublic();
			PrivateKey privateKey = keyPair.getPrivate();
			recentPrivateKey = privateKey;
			
			RSAPublicKeySpec publicKeySpec = (RSAPublicKeySpec)keyFactory.getKeySpec(publicKey, RSAPublicKeySpec.class);
			
			String publicKeyModulus = publicKeySpec.getModulus().toString(16);
			String publicKeyExponent = publicKeySpec.getPublicExponent().toString(16);
			
			request.setAttribute("PublicKeyModulus", publicKeyModulus);
			request.setAttribute("PublicKeyExponent", publicKeyExponent);
			
			request.getRequestDispatcher("/WEB-INF/hextest.jsp").forward(request, response);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
    /**
     * 16진 문자열을 byte 배열로 변환한다.
     */
    public static byte[] hexToByteArray(String hex) {
        if (hex == null || hex.length() % 2 != 0) {
            return new byte[]{};
        }

        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length(); i += 2) {
            byte value = (byte)Integer.parseInt(hex.substring(i, i + 2), 16);
            bytes[(int) Math.floor(i / 2)] = value;
        }
        return bytes;
    }
}
